// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode and checksum"); }
int main(){
  announce();
  return lionss_run_workload("flac_md5");
}
