# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(duskfall src/duskfall.cpp)
set_property(TARGET duskfall PROPERTY CXX_STANDARD 11)
target_link_libraries(duskfall lionss pthread)

add_executable(SilverBirch src/SilverBirch.cpp)
set_property(TARGET SilverBirch PROPERTY CXX_STANDARD 11)
target_link_libraries(SilverBirch lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(icc_profile src/icc_profile.cpp)
set_property(TARGET icc_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(icc_profile lionss pthread)

add_executable(grafanaPanel src/grafanaPanel.cpp)
set_property(TARGET grafanaPanel PROPERTY CXX_STANDARD 11)
target_link_libraries(grafanaPanel lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(nsga2_front src/nsga2_front.cpp)
set_property(TARGET nsga2_front PROPERTY CXX_STANDARD 11)
target_link_libraries(nsga2_front lionss pthread)

add_executable(denoiseNlm src/denoiseNlm.cpp)
set_property(TARGET denoiseNlm PROPERTY CXX_STANDARD 11)
target_link_libraries(denoiseNlm lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(assetBundleV3 src/assetBundleV3.cpp)
set_property(TARGET assetBundleV3 PROPERTY CXX_STANDARD 11)
target_link_libraries(assetBundleV3 lionss pthread)

add_executable(verglas src/verglas.cpp)
set_property(TARGET verglas PROPERTY CXX_STANDARD 11)
target_link_libraries(verglas lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(anchorAudit src/anchorAudit.cpp)
set_property(TARGET anchorAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(anchorAudit lionss pthread)

add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

add_executable(numpystub src/numpystub.cpp)
set_property(TARGET numpystub PROPERTY CXX_STANDARD 11)
target_link_libraries(numpystub lionss pthread)

add_executable(kingfisher-3 src/kingfisher-3.cpp)
set_property(TARGET kingfisher-3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kingfisher-3 lionss pthread)

add_executable(ropeScale src/ropeScale.cpp)
set_property(TARGET ropeScale PROPERTY CXX_STANDARD 11)
target_link_libraries(ropeScale lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(jitterbuffer src/jitterbuffer.cpp)
set_property(TARGET jitterbuffer PROPERTY CXX_STANDARD 11)
target_link_libraries(jitterbuffer lionss pthread)

add_executable(quantize_awq src/quantize_awq.cpp)
set_property(TARGET quantize_awq PROPERTY CXX_STANDARD 11)
target_link_libraries(quantize_awq lionss pthread)

add_executable(ql-planner src/ql-planner.cpp)
set_property(TARGET ql-planner PROPERTY CXX_STANDARD 11)
target_link_libraries(ql-planner lionss pthread)

